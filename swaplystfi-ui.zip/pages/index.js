export default function Home() {
  return (
    <div className="min-h-screen bg-[#f5f7fa] flex flex-col items-center py-10 px-4">
      <header className="w-full max-w-4xl mb-6 text-center">
        <h1 className="text-3xl font-bold text-gray-800">SwaplystFi</h1>
        <p className="text-gray-500 text-sm mt-1">All Chains. One Aggregator.</p>
      </header>

      <div className="w-full max-w-4xl rounded-2xl overflow-hidden shadow-xl border border-gray-200">
        <iframe
          src="https://app.uniswap.org/#/swap?theme=light"
          className="w-full h-[660px]"
          allow="clipboard-write; clipboard-read; fullscreen"
        ></iframe>
      </div>

      <footer className="text-center text-gray-400 text-sm mt-8">
        &copy; 2025 SwaplystFi. All rights reserved.
        <div className="mt-1 text-xs">
          Powered by <a href="https://uniswap.org" target="_blank" className="text-purple-600 font-medium">Uniswap</a>
        </div>
      </footer>
    </div>
  );
}
